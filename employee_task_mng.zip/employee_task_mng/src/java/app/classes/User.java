package app.classes;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class User {

    private int id;
    private String name;
    private String email;
    private String password;
    private String role;

    // Constructor
    public User(int id,String name, String email, String password, String role) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.password = password;
        this.role = role;
    }
    public User(String name, String email, String password, String role) {
        this.name = name;
        this.email = email;
        this.password = password;
        this.role = role;
    }
    public User(String name, String email, String password) {
        this.name = name;
        this.email = email;
        this.password = password;
        this.role = "User";
    }
      public User( String email) {
        this.name = name;
        this.email = email;
        this.password = password;
        this.role = role;
    }


    

    // CRUD Operations

    // Create (Register)
    public static boolean registerUser(User user) {
        String query = "INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)";
        try (Connection con = DbConnector.getConnection();
             PreparedStatement pst = con.prepareStatement(query)) {
            pst.setString(1, user.name);
            pst.setString(2, user.email);
            pst.setString(3, user.password);
            pst.setString(4, user.role);
            return pst.executeUpdate() > 0;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }

 
    // Read (Login)
public static User loginUser(String email, String password) {
    String query = "SELECT * FROM users WHERE email = ? AND password = ?";
    try (Connection con = DbConnector.getConnection();
         PreparedStatement pst = con.prepareStatement(query)) {
        pst.setString(1, email);
        pst.setString(2, password);
        ResultSet rs = pst.executeQuery();
        if (rs.next()) {
            // Returning the full user object including the id
            return new User(
                rs.getInt("id"), 
                rs.getString("name"), 
                rs.getString("email"), 
                rs.getString("password"), 
                rs.getString("role")
            );
        }
    } catch (SQLException ex) {
        ex.printStackTrace();
    }
    return null; // Return null if no matching user is found
}

    // Update
    public static boolean updateUser(User user) {
        String query = "UPDATE users SET name = ?, email = ?, password = ?, role = ? WHERE id = ?";
        try (Connection con = DbConnector.getConnection();
             PreparedStatement pst = con.prepareStatement(query)) {
            pst.setString(1, user.name);
            pst.setString(2, user.email);
            pst.setString(3, user.password);
            pst.setString(4, user.role);
            pst.setInt(5, user.id);
            return pst.executeUpdate() > 0;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }

    // Delete
    public static boolean deleteUser(int userId) {
        String query = "DELETE FROM users WHERE id = ?";
        try (Connection con = DbConnector.getConnection();
             PreparedStatement pst = con.prepareStatement(query)) {
            pst.setInt(1, userId);
            return pst.executeUpdate() > 0;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }
    
 
    // Get all users
    public static List<User> getAllUsers() {
        List<User> users = new ArrayList<>();
        String query = "SELECT * FROM users";
        try (Connection con = DbConnector.getConnection();
             PreparedStatement pst = con.prepareStatement(query);
             ResultSet rs = pst.executeQuery()) {
            while (rs.next()) {
                users.add(new User(
                    rs.getInt("id"),
                    rs.getString("name"),
                    rs.getString("email"),
                    rs.getString("password"),
                    rs.getString("role")
                ));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return users;
    }



    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }
    
    
    
    
    // User.java

// Get the count of users by role
public static int getUserCountByRole(String role) {
    String query = "SELECT COUNT(*) FROM users WHERE role = ?";
    try (Connection con = DbConnector.getConnection();
         PreparedStatement pst = con.prepareStatement(query)) {
        pst.setString(1, role);
        ResultSet rs = pst.executeQuery();
        if (rs.next()) {
            return rs.getInt(1);
        }
    } catch (SQLException ex) {
        ex.printStackTrace();
    }
    return 0;
}

// Get total user count
public static int getTotalUserCount() {
    String query = "SELECT COUNT(*) FROM users";
    try (Connection con = DbConnector.getConnection();
         PreparedStatement pst = con.prepareStatement(query);
         ResultSet rs = pst.executeQuery()) {
        if (rs.next()) {
            return rs.getInt(1);
        }
    } catch (SQLException ex) {
        ex.printStackTrace();
    }
    return 0;
}

public static User getUserById(int userId) {
    String query = "SELECT * FROM users WHERE id = ?";
    try (Connection con = DbConnector.getConnection();
         PreparedStatement pst = con.prepareStatement(query)) {
        pst.setInt(1, userId);
        ResultSet rs = pst.executeQuery();
        if (rs.next()) {
            return new User(
                rs.getInt("id"),
                rs.getString("name"),
                rs.getString("email"),
                rs.getString("password"),
                rs.getString("role")
            );
        }
    } catch (SQLException ex) {
        ex.printStackTrace();
    }
    return null;
}

}


