package app.classes;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Task {

    private int id;
    private String title;
    private String assignedDate;
    private String dueDate;
    private String status;
    private int userId;

    // Constructor
    public Task(String title, String assignedDate, String dueDate, String status, int userId) {
        this.title = title;
        this.assignedDate = assignedDate;
        this.dueDate = dueDate;
        this.status = status;
        this.userId = userId;
    }

    public Task(int id, String title, String assignedDate, String dueDate, String status, int userId) {
        this.id = id;
        this.title = title;
        this.assignedDate = assignedDate;
        this.dueDate = dueDate;
        this.status = status;
        this.userId = userId;
    }
    
    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAssignedDate() {
        return assignedDate;
    }

    public void setAssignedDate(String assignedDate) {
        this.assignedDate = assignedDate;
    }

    public String getDueDate() {
        return dueDate;
    }

    public void setDueDate(String dueDate) {
        this.dueDate = dueDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }
    
    
    
    
    
    // Task.java

// Get counts of tasks by status
public static int getTaskCountByStatus(String status) {
    String query = "SELECT COUNT(*) FROM tasks WHERE status = ?";
    try (Connection con = DbConnector.getConnection();
         PreparedStatement pst = con.prepareStatement(query)) {
        pst.setString(1, status);
        ResultSet rs = pst.executeQuery();
        if (rs.next()) {
            return rs.getInt(1);
        }
    } catch (SQLException ex) {
        ex.printStackTrace();
    }
    return 0;
}

// Get total task count
public static int getTotalTaskCount() {
    String query = "SELECT COUNT(*) FROM tasks";
    try (Connection con = DbConnector.getConnection();
         PreparedStatement pst = con.prepareStatement(query);
         ResultSet rs = pst.executeQuery()) {
        if (rs.next()) {
            return rs.getInt(1);
        }
    } catch (SQLException ex) {
        ex.printStackTrace();
    }
    return 0;
}
// CRUD Operations

    // Create
    public static boolean createTask(Task task) {
        String query = "INSERT INTO tasks (title, assigned_date, due_date, status, user_id) VALUES (?, ?, ?, ?, ?)";
        try (Connection con = DbConnector.getConnection();
                PreparedStatement pst = con.prepareStatement(query)) {
            pst.setString(1, task.title);
            pst.setString(2, task.assignedDate);
            pst.setString(3, task.dueDate);
            pst.setString(4, task.status);
            pst.setInt(5, task.userId);
            return pst.executeUpdate() > 0;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }

    // Read
    public static Task getTask(int taskId) {
        String query = "SELECT * FROM tasks WHERE id = ?";
        try (Connection con = DbConnector.getConnection();
                PreparedStatement pst = con.prepareStatement(query)) {
            pst.setInt(1, taskId);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                return new Task(rs.getInt("id"), rs.getString("title"), rs.getString("assigned_date"), rs.getString("due_date"), rs.getString("status"), rs.getInt("user_id"));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return null;
    }

    // Update
    public static boolean updateTask(Task task) {
        String query = "UPDATE tasks SET title = ?, assigned_date = ?, due_date = ?, status = ?, user_id = ? WHERE id = ?";
        try (Connection con = DbConnector.getConnection();
                PreparedStatement pst = con.prepareStatement(query)) {

            pst.setString(1, task.getTitle());
            pst.setString(2, task.getAssignedDate());
            pst.setString(3, task.getDueDate());
            pst.setString(4, task.getStatus());
            pst.setInt(5, task.getUserId());
            pst.setInt(6, task.getId());

            System.out.println("Updating task with ID: " + task.getId());
            System.out.println("Title: " + task.getTitle());
            System.out.println("Assigned Date: " + task.getAssignedDate());
            System.out.println("Due Date: " + task.getDueDate());
            System.out.println("Status: " + task.getStatus());
            System.out.println("UserId: " + task.getUserId());

            return pst.executeUpdate() > 0;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }

    public static boolean updateStatus(Task task) {
        String query = "UPDATE tasks SET status = ? WHERE id = ?";
        try (Connection con = DbConnector.getConnection();
                PreparedStatement pst = con.prepareStatement(query)) {
            pst.setString(1, task.status);
            pst.setInt(2, task.id);
            System.out.println(task.getStatus());
            return pst.executeUpdate() > 0;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }

    // Delete
    public static boolean deleteTask(int taskId) {
        String query = "DELETE FROM tasks WHERE id = ?";
        try (Connection con = DbConnector.getConnection();
                PreparedStatement pst = con.prepareStatement(query)) {
            pst.setInt(1, taskId);
            return pst.executeUpdate() > 0;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }

    public static List<Task> getAllTasks() {
        List<Task> tasks = new ArrayList<>();
        String query = "SELECT * FROM tasks";
        try (Connection con = DbConnector.getConnection();
                PreparedStatement pst = con.prepareStatement(query);
                ResultSet rs = pst.executeQuery()) {

            while (rs.next()) {
                Task task = new Task(
                        rs.getString("title"),
                        rs.getString("assigned_date"),
                        rs.getString("due_date"),
                        rs.getString("status"),
                        rs.getInt("user_id")
                );
                task.setId(rs.getInt("id"));
                tasks.add(task);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return tasks;
    }


public static List<Task> getTasksByUserId(int userId) {
    List<Task> tasks = new ArrayList<>();
    String query = "SELECT * FROM tasks WHERE user_id = ?";
    try (Connection con = DbConnector.getConnection();
         PreparedStatement pst = con.prepareStatement(query)) {

        pst.setInt(1, userId);
        ResultSet rs = pst.executeQuery();

        while (rs.next()) {
            Task task = new Task(
                    rs.getString("title"),
                    rs.getString("assigned_date"),
                    rs.getString("due_date"),
                    rs.getString("status"),
                    rs.getInt("user_id")
            );
            task.setId(rs.getInt("id"));
            tasks.add(task);
        }
    } catch (SQLException ex) {
        ex.printStackTrace();
    }
    return tasks;
}


}


